﻿using Stride.Engine;
using Stride.Rendering.Compositing;
using Stride.Games;

namespace MyGame
{
    public class MyraStartup : StartupScript
    {
        /// <summary>
        /// This method code had been borrowed from here: https://github.com/stride3d/stride-community-toolkit
        /// Adds a new scene renderer to the given GraphicsCompositor's game. If the game is already a collection of scene renderers,
        /// the new scene renderer is added to that collection. Otherwise, a new scene renderer collection is created to house both
        /// the existing game and the new scene renderer.
        /// </summary>
        /// <param name="graphicsCompositor">The GraphicsCompositor to which the scene renderer will be added.</param>
        /// <param name="sceneRenderer">The new <see cref="SceneRendererBase"/> instance that will be added to the GraphicsCompositor's game.</param>
        /// <remarks>
        /// This method will either add the scene renderer to an existing SceneRendererCollection or create a new one to house both
        /// the existing game and the new scene renderer. In either case, the GraphicsCompositor's game will end up with the new scene renderer added.
        /// </remarks>
        /// <returns>Returns the modified GraphicsCompositor instance, allowing for method chaining.</returns>
        private static GraphicsCompositor AddSceneRenderer(GraphicsCompositor graphicsCompositor, SceneRendererBase sceneRenderer)
        {
            if (graphicsCompositor.Game is SceneRendererCollection sceneRendererCollection)
            {
                sceneRendererCollection.Children.Add(sceneRenderer);
            }
            else
            {
                var newSceneRendererCollection = new SceneRendererCollection();

                newSceneRendererCollection.Children.Add(graphicsCompositor.Game);
                newSceneRendererCollection.Children.Add(sceneRenderer);

                graphicsCompositor.Game = newSceneRendererCollection;
            }

            return graphicsCompositor;
        }

        public override void Start()
        {
            // Initialization of the script.
            var game = (Game)Services.GetService<IGame>();

            AddSceneRenderer(game.SceneSystem.GraphicsCompositor, new MyraRenderer());
        }
    }
}